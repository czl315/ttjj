package com.gupaoedu.vip.design.principle.dependencyinversion;

/**
 * Created by Tom on 2020/2/16.
 */
public class PythonCourse implements ICourse {
    public void study() {
        System.out.println("Tom正在学习Python课程");
    }
}

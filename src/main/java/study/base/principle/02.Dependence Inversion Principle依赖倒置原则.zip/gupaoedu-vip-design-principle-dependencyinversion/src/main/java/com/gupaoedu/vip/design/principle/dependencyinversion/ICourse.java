package com.gupaoedu.vip.design.principle.dependencyinversion;

/**
 * Created by Tom on 2020/2/16.
 */
public interface ICourse {
    void study();
}

package com.gupaoedu.vip.design.principle.interfacesegregation.simple;

/**
 * Created by Tom on 2020/2/16.
 */
public class Dog implements IAnimal {
    public void eat() {

    }

    public void fly() {

    }

    public void swim() {

    }
}

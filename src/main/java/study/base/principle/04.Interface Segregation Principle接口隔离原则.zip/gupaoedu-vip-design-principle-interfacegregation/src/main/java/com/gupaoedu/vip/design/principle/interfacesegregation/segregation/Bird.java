package com.gupaoedu.vip.design.principle.interfacesegregation.segregation;

/**
 * Created by Tom on 2020/2/16.
 */
public class Bird implements IEatAminal,IFlyAminal {
    public void eat() {

    }

    public void fly() {

    }
}

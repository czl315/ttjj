package com.gupaoedu.vip.design.principle.interfacesegregation.segregation;

/**
 * Created by Tom on 2020/2/16.
 */
public class Dog implements ISwimAminal,IEatAminal {
    public void eat() {

    }

    public void swin() {

    }
}

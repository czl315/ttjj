package com.gupaoedu.vip.design.principle.openclose;

/**
 * Created by Tom on 2020/2/16.
 */
public interface ICourse {
    Integer getId();
    String getName();
    Double getPrice();
}

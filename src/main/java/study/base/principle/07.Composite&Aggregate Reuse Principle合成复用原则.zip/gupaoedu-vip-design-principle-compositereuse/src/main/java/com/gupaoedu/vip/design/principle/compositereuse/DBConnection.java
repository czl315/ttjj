package com.gupaoedu.vip.design.principle.compositereuse;

/**
 * Created by Tom on 2020/2/17.
 */
public abstract class DBConnection {
    public abstract String getConnection();

//    getConnection{
//        return "获取MySQL数据连接";
//    }
//    public String getOracleConntion(){}
}

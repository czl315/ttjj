package com.gupaoedu.vip.design.principle.simpleresponsibility.interfaced;

/**
 * Created by Tom on 2020/2/16.
 */
public interface ICourseManager {

    void studyCourse();
    void refundCourse();
}

package com.gupaoedu.vip.design.principle.simpleresponsibility.simple;

/**
 * Created by Tom on 2020/2/16.
 */
public class ReplayCourse {
    public  void  study(String courseName){
        System.out.println("可以任意的来回播放");
    }
}

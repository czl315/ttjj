package com.gupaoedu.vip.design.principle.liskovsutiution.methodreturn;

import java.util.Map;

/**
 * Created by Tom on 2020/2/16.
 */
public abstract class Base {
    public abstract Map method();
}

package com.gupaoedu.vip.design.principle.liskovsutiution.methodparam;

import java.util.HashMap;

/**
 * Created by Tom on 2020/2/16.
 */
public class Base {
    public void method(HashMap map){
        System.out.println("父类执行");
    }
}

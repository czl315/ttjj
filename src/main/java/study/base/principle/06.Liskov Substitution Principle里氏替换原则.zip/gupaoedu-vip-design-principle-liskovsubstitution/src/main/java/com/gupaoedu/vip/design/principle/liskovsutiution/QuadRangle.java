package com.gupaoedu.vip.design.principle.liskovsutiution;

/**
 * Created by Tom on 2020/2/16.
 */
public interface QuadRangle {
    long getWidth();
    long getHeight();
}
